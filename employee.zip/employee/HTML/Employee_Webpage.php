<html>
<head>
<title>Employee Interface</title>

<style>
body {
	background-image: url('Orange Background.png');

}
.vertical-menu {
  width: 200px;
}
.vertical-menu a {
  background-color: #eee;
  color: black;
  display: block;
  padding: 12px;
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
</head>

<body>

	<center><img src = "Icon.png" alt="User Image" width="400" height="400"></center>
	

<h1>Menu</h1>

<div class="vertical-menu">
    <a href="#" class="active">Home</a>
    <a href="#">Apply For Leave</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
    <a href="#">Link 4</a>
</div>
	

</body>
</html>